"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { ChatInterface } from "@/components/chat-interface"
import { PatientProfile } from "@/components/patient-profile"
import { PatientList } from "@/components/patient-list"
import { Users, MessageSquare } from "lucide-react"
import { cn } from "@/lib/utils"

export default function Home() {
  const [selectedPatient, setSelectedPatient] = useState<string | null>(null)
  const [mobileView, setMobileView] = useState<"list" | "chat" | "profile">("chat")

  const handlePatientSelect = (patientId: string) => {
    setSelectedPatient(patientId)
    setMobileView("profile")
  }

  const handleCloseProfile = () => {
    setSelectedPatient(null)
    setMobileView("chat")
  }

  return (
    <div className="flex h-screen flex-col bg-background">
      <Header />
      
      {/* Mobile Navigation */}
      <div className="flex border-b bg-card p-2 gap-2 md:hidden">
        <button
          onClick={() => setMobileView("list")}
          className={cn(
            "flex-1 flex items-center justify-center gap-2 rounded-lg py-2 text-sm font-medium transition-colors",
            mobileView === "list"
              ? "bg-primary text-primary-foreground"
              : "bg-muted text-muted-foreground hover:text-foreground"
          )}
        >
          <Users className="h-4 w-4" />
          Patients
        </button>
        <button
          onClick={() => setMobileView("chat")}
          className={cn(
            "flex-1 flex items-center justify-center gap-2 rounded-lg py-2 text-sm font-medium transition-colors",
            mobileView === "chat"
              ? "bg-primary text-primary-foreground"
              : "bg-muted text-muted-foreground hover:text-foreground"
          )}
        >
          <MessageSquare className="h-4 w-4" />
          Chat
        </button>
      </div>

      <main className="flex flex-1 overflow-hidden">
        {/* Patient List - Desktop Sidebar */}
        <aside className="hidden md:block w-80 shrink-0 border-r bg-background p-4">
          <PatientList
            selectedPatient={selectedPatient}
            onSelectPatient={handlePatientSelect}
          />
        </aside>

        {/* Mobile Patient List */}
        <div
          className={cn(
            "absolute inset-0 top-[calc(4rem+3rem)] z-10 bg-background p-4 md:hidden",
            mobileView === "list" ? "block" : "hidden"
          )}
        >
          <PatientList
            selectedPatient={selectedPatient}
            onSelectPatient={handlePatientSelect}
          />
        </div>

        {/* Chat Interface */}
        <div
          className={cn(
            "flex-1 p-4 md:block",
            mobileView === "chat" ? "block" : "hidden md:block"
          )}
        >
          <div className="h-full">
            <ChatInterface onPatientMention={handlePatientSelect} />
          </div>
        </div>

        {/* Patient Profile - Desktop Panel */}
        {selectedPatient && (
          <aside className="hidden md:block w-96 shrink-0 border-l bg-background p-4">
            <PatientProfile
              patientId={selectedPatient}
              onClose={handleCloseProfile}
            />
          </aside>
        )}

        {/* Mobile Patient Profile */}
        {selectedPatient && (
          <div
            className={cn(
              "absolute inset-0 top-[calc(4rem+3rem)] z-20 bg-background p-4 md:hidden",
              mobileView === "profile" ? "block" : "hidden"
            )}
          >
            <PatientProfile
              patientId={selectedPatient}
              onClose={handleCloseProfile}
            />
          </div>
        )}
      </main>
    </div>
  )
}
