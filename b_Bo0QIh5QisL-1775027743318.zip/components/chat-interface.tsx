"use client"

import { useState, useRef, useEffect } from "react"
import { Send, Bot, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
  patientId?: string
}

interface ChatInterfaceProps {
  onPatientMention: (patientId: string) => void
}

const samplePatients = [
  { id: "P001", name: "Sarah Johnson" },
  { id: "P002", name: "Michael Chen" },
  { id: "P003", name: "Emily Davis" },
  { id: "P004", name: "Robert Wilson" },
]

export function ChatInterface({ onPatientMention }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Hello! I&apos;m your healthcare assistant. I can help you access patient profiles and medical information. Try asking about a patient by name or ID (e.g., &quot;Show me Sarah Johnson&apos;s profile&quot; or &quot;Open patient P001&quot;).",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  const handleSend = async () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    // Check for patient mentions
    const matchedPatient = samplePatients.find(
      (p) =>
        input.toLowerCase().includes(p.name.toLowerCase()) ||
        input.toLowerCase().includes(p.id.toLowerCase())
    )

    setTimeout(() => {
      let response: string
      let patientId: string | undefined

      if (matchedPatient) {
        response = `I&apos;ve found ${matchedPatient.name}&apos;s profile (ID: ${matchedPatient.id}). I&apos;m opening their patient record now. You can see their complete medical history, current medications, and upcoming appointments in the panel on the right.`
        patientId = matchedPatient.id
        onPatientMention(matchedPatient.id)
      } else if (input.toLowerCase().includes("patient") || input.toLowerCase().includes("profile")) {
        response = "I can help you find patient profiles. Please provide a patient name or ID. Available patients: Sarah Johnson (P001), Michael Chen (P002), Emily Davis (P003), or Robert Wilson (P004)."
      } else if (input.toLowerCase().includes("help") || input.toLowerCase().includes("what can")) {
        response = "I can assist you with:\n• Opening patient profiles\n• Viewing medical history\n• Checking medications\n• Reviewing lab results\n• Scheduling appointments\n\nJust ask about any patient by name or ID!"
      } else {
        response = "I&apos;m here to help with patient information. Try asking me to &quot;show patient P001&quot; or &quot;open Sarah Johnson&apos;s profile&quot;."
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response,
        timestamp: new Date(),
        patientId,
      }

      setMessages((prev) => [...prev, assistantMessage])
      setIsTyping(false)
    }, 1000)
  }

  return (
    <div className="flex h-full flex-col bg-card rounded-xl border shadow-sm">
      {/* Header */}
      <div className="flex items-center gap-3 border-b px-6 py-4">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary">
          <Bot className="h-5 w-5 text-primary-foreground" />
        </div>
        <div>
          <h2 className="font-semibold text-card-foreground">MedChat Assistant</h2>
          <p className="text-sm text-muted-foreground">Patient Care Support</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-green-500" />
          <span className="text-sm text-muted-foreground">Online</span>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-6" ref={scrollRef}>
        <div className="space-y-6">
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                "flex gap-3",
                message.role === "user" ? "flex-row-reverse" : "flex-row"
              )}
            >
              <Avatar className="h-8 w-8 shrink-0">
                <AvatarFallback
                  className={cn(
                    message.role === "user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-accent text-accent-foreground"
                  )}
                >
                  {message.role === "user" ? (
                    <User className="h-4 w-4" />
                  ) : (
                    <Bot className="h-4 w-4" />
                  )}
                </AvatarFallback>
              </Avatar>
              <div
                className={cn(
                  "max-w-[75%] rounded-2xl px-4 py-3",
                  message.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-card-foreground"
                )}
              >
                <p className="text-sm leading-relaxed whitespace-pre-line">{message.content}</p>
                <p
                  className={cn(
                    "mt-1 text-xs",
                    message.role === "user"
                      ? "text-primary-foreground/70"
                      : "text-muted-foreground"
                  )}
                >
                  {message.timestamp.toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex gap-3">
              <Avatar className="h-8 w-8 shrink-0">
                <AvatarFallback className="bg-accent text-accent-foreground">
                  <Bot className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
              <div className="rounded-2xl bg-muted px-4 py-3">
                <div className="flex gap-1">
                  <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground [animation-delay:0ms]" />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground [animation-delay:150ms]" />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground [animation-delay:300ms]" />
                </div>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="border-t p-4">
        <form
          onSubmit={(e) => {
            e.preventDefault()
            handleSend()
          }}
          className="flex gap-3"
        >
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about a patient..."
            className="flex-1 bg-background"
          />
          <Button type="submit" size="icon" disabled={!input.trim()}>
            <Send className="h-4 w-4" />
            <span className="sr-only">Send message</span>
          </Button>
        </form>
      </div>
    </div>
  )
}
