"use client"

import {
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Pill,
  FileText,
  Activity,
  AlertCircle,
  Clock,
  Heart,
  X,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface PatientProfileProps {
  patientId: string
  onClose: () => void
}

const patientData: Record<
  string,
  {
    id: string
    name: string
    age: number
    gender: string
    dob: string
    phone: string
    email: string
    address: string
    bloodType: string
    allergies: string[]
    conditions: string[]
    medications: { name: string; dosage: string; frequency: string }[]
    vitals: { label: string; value: string; status: "normal" | "warning" | "critical" }[]
    appointments: { date: string; type: string; doctor: string }[]
    recentVisits: { date: string; reason: string; notes: string }[]
  }
> = {
  P001: {
    id: "P001",
    name: "Sarah Johnson",
    age: 45,
    gender: "Female",
    dob: "March 15, 1981",
    phone: "(555) 123-4567",
    email: "sarah.johnson@email.com",
    address: "123 Oak Street, Portland, OR 97201",
    bloodType: "A+",
    allergies: ["Penicillin", "Sulfa drugs"],
    conditions: ["Type 2 Diabetes", "Hypertension"],
    medications: [
      { name: "Metformin", dosage: "500mg", frequency: "Twice daily" },
      { name: "Lisinopril", dosage: "10mg", frequency: "Once daily" },
      { name: "Aspirin", dosage: "81mg", frequency: "Once daily" },
    ],
    vitals: [
      { label: "Blood Pressure", value: "138/88 mmHg", status: "warning" },
      { label: "Heart Rate", value: "72 bpm", status: "normal" },
      { label: "Blood Glucose", value: "145 mg/dL", status: "warning" },
      { label: "Temperature", value: "98.6°F", status: "normal" },
    ],
    appointments: [
      { date: "Apr 15, 2026", type: "Follow-up", doctor: "Dr. Emily Roberts" },
      { date: "May 1, 2026", type: "Lab Work", doctor: "Lab Services" },
    ],
    recentVisits: [
      {
        date: "Mar 20, 2026",
        reason: "Routine Check-up",
        notes: "Blood pressure slightly elevated. Adjusted medication.",
      },
      {
        date: "Feb 10, 2026",
        reason: "Diabetes Management",
        notes: "A1C improved to 7.2%. Continue current regimen.",
      },
    ],
  },
  P002: {
    id: "P002",
    name: "Michael Chen",
    age: 32,
    gender: "Male",
    dob: "July 22, 1993",
    phone: "(555) 234-5678",
    email: "m.chen@email.com",
    address: "456 Pine Avenue, Seattle, WA 98101",
    bloodType: "O-",
    allergies: ["Latex"],
    conditions: ["Asthma", "Seasonal allergies"],
    medications: [
      { name: "Albuterol", dosage: "90mcg", frequency: "As needed" },
      { name: "Fluticasone", dosage: "50mcg", frequency: "Twice daily" },
      { name: "Cetirizine", dosage: "10mg", frequency: "Once daily" },
    ],
    vitals: [
      { label: "Blood Pressure", value: "118/76 mmHg", status: "normal" },
      { label: "Heart Rate", value: "68 bpm", status: "normal" },
      { label: "SpO2", value: "98%", status: "normal" },
      { label: "Peak Flow", value: "520 L/min", status: "normal" },
    ],
    appointments: [
      { date: "Apr 8, 2026", type: "Pulmonology", doctor: "Dr. James Wilson" },
    ],
    recentVisits: [
      {
        date: "Mar 5, 2026",
        reason: "Asthma Review",
        notes: "Well controlled. No changes to medication.",
      },
    ],
  },
  P003: {
    id: "P003",
    name: "Emily Davis",
    age: 67,
    gender: "Female",
    dob: "November 8, 1958",
    phone: "(555) 345-6789",
    email: "emily.d@email.com",
    address: "789 Maple Drive, Denver, CO 80202",
    bloodType: "B+",
    allergies: ["Codeine", "Shellfish"],
    conditions: ["Atrial Fibrillation", "Osteoarthritis", "Hypothyroidism"],
    medications: [
      { name: "Warfarin", dosage: "5mg", frequency: "Once daily" },
      { name: "Metoprolol", dosage: "25mg", frequency: "Twice daily" },
      { name: "Levothyroxine", dosage: "75mcg", frequency: "Once daily" },
      { name: "Acetaminophen", dosage: "500mg", frequency: "As needed" },
    ],
    vitals: [
      { label: "Blood Pressure", value: "142/92 mmHg", status: "warning" },
      { label: "Heart Rate", value: "88 bpm (irregular)", status: "warning" },
      { label: "INR", value: "2.8", status: "normal" },
      { label: "TSH", value: "2.1 mIU/L", status: "normal" },
    ],
    appointments: [
      { date: "Apr 5, 2026", type: "Cardiology", doctor: "Dr. Sarah Kim" },
      { date: "Apr 20, 2026", type: "INR Check", doctor: "Lab Services" },
    ],
    recentVisits: [
      {
        date: "Mar 15, 2026",
        reason: "Cardiology Follow-up",
        notes: "AFib well controlled. Continue current anticoagulation.",
      },
    ],
  },
  P004: {
    id: "P004",
    name: "Robert Wilson",
    age: 55,
    gender: "Male",
    dob: "January 30, 1971",
    phone: "(555) 456-7890",
    email: "r.wilson@email.com",
    address: "321 Cedar Lane, Austin, TX 78701",
    bloodType: "AB+",
    allergies: [],
    conditions: ["GERD", "Anxiety disorder"],
    medications: [
      { name: "Omeprazole", dosage: "20mg", frequency: "Once daily" },
      { name: "Sertraline", dosage: "50mg", frequency: "Once daily" },
    ],
    vitals: [
      { label: "Blood Pressure", value: "124/80 mmHg", status: "normal" },
      { label: "Heart Rate", value: "76 bpm", status: "normal" },
      { label: "Weight", value: "185 lbs", status: "normal" },
      { label: "BMI", value: "26.4", status: "warning" },
    ],
    appointments: [
      { date: "Apr 25, 2026", type: "Annual Physical", doctor: "Dr. Mark Thompson" },
    ],
    recentVisits: [
      {
        date: "Feb 28, 2026",
        reason: "Medication Review",
        notes: "GERD symptoms improved. Anxiety well managed.",
      },
    ],
  },
}

export function PatientProfile({ patientId, onClose }: PatientProfileProps) {
  const patient = patientData[patientId]

  if (!patient) {
    return (
      <Card className="h-full">
        <CardContent className="flex h-full items-center justify-center">
          <p className="text-muted-foreground">Patient not found</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="h-full flex flex-col overflow-hidden">
      <CardHeader className="border-b pb-4 shrink-0">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16">
              <AvatarFallback className="bg-primary text-primary-foreground text-lg">
                {patient.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <div>
              <CardTitle className="text-xl">{patient.name}</CardTitle>
              <p className="text-muted-foreground">
                {patient.age} years old • {patient.gender} • ID: {patient.id}
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                <Badge variant="outline" className="gap-1">
                  <Heart className="h-3 w-3" />
                  {patient.bloodType}
                </Badge>
                {patient.allergies.length > 0 && (
                  <Badge variant="destructive" className="gap-1">
                    <AlertCircle className="h-3 w-3" />
                    {patient.allergies.length} Allergies
                  </Badge>
                )}
              </div>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} className="shrink-0">
            <X className="h-4 w-4" />
            <span className="sr-only">Close profile</span>
          </Button>
        </div>
      </CardHeader>

      <Tabs defaultValue="overview" className="flex-1 flex flex-col overflow-hidden">
        <TabsList className="w-full justify-start rounded-none border-b bg-transparent px-4 shrink-0">
          <TabsTrigger value="overview" className="data-[state=active]:bg-background">
            Overview
          </TabsTrigger>
          <TabsTrigger value="medical" className="data-[state=active]:bg-background">
            Medical
          </TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-background">
            History
          </TabsTrigger>
        </TabsList>

        <ScrollArea className="flex-1">
          <TabsContent value="overview" className="m-0 p-4 space-y-4">
            {/* Contact Info */}
            <div className="space-y-3">
              <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">
                Contact Information
              </h3>
              <div className="grid gap-3">
                <div className="flex items-center gap-3 text-sm">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>Born {patient.dob}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span>{patient.phone}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span>{patient.email}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span>{patient.address}</span>
                </div>
              </div>
            </div>

            <Separator />

            {/* Vitals */}
            <div className="space-y-3">
              <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">
                Current Vitals
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {patient.vitals.map((vital) => (
                  <div
                    key={vital.label}
                    className="rounded-lg border p-3 bg-background"
                  >
                    <p className="text-xs text-muted-foreground">{vital.label}</p>
                    <div className="mt-1 flex items-center gap-2">
                      <span className="font-medium">{vital.value}</span>
                      <span
                        className={`h-2 w-2 rounded-full ${
                          vital.status === "normal"
                            ? "bg-green-500"
                            : vital.status === "warning"
                            ? "bg-yellow-500"
                            : "bg-red-500"
                        }`}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <Separator />

            {/* Upcoming Appointments */}
            <div className="space-y-3">
              <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">
                Upcoming Appointments
              </h3>
              <div className="space-y-2">
                {patient.appointments.map((apt, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-3 rounded-lg border p-3 bg-background"
                  >
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <Clock className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{apt.type}</p>
                      <p className="text-xs text-muted-foreground">
                        {apt.date} • {apt.doctor}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="medical" className="m-0 p-4 space-y-4">
            {/* Conditions */}
            <div className="space-y-3">
              <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                <Activity className="h-4 w-4" />
                Active Conditions
              </h3>
              <div className="flex flex-wrap gap-2">
                {patient.conditions.map((condition) => (
                  <Badge key={condition} variant="secondary">
                    {condition}
                  </Badge>
                ))}
              </div>
            </div>

            <Separator />

            {/* Allergies */}
            <div className="space-y-3">
              <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                <AlertCircle className="h-4 w-4" />
                Allergies
              </h3>
              {patient.allergies.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {patient.allergies.map((allergy) => (
                    <Badge key={allergy} variant="destructive">
                      {allergy}
                    </Badge>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No known allergies</p>
              )}
            </div>

            <Separator />

            {/* Medications */}
            <div className="space-y-3">
              <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                <Pill className="h-4 w-4" />
                Current Medications
              </h3>
              <div className="space-y-2">
                {patient.medications.map((med, i) => (
                  <div
                    key={i}
                    className="rounded-lg border p-3 bg-background"
                  >
                    <p className="font-medium text-sm">{med.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {med.dosage} • {med.frequency}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="history" className="m-0 p-4 space-y-4">
            {/* Recent Visits */}
            <div className="space-y-3">
              <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Recent Visits
              </h3>
              <div className="space-y-3">
                {patient.recentVisits.map((visit, i) => (
                  <div
                    key={i}
                    className="rounded-lg border p-4 bg-background space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-sm">{visit.reason}</p>
                      <Badge variant="outline" className="text-xs">
                        {visit.date}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{visit.notes}</p>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </Card>
  )
}
