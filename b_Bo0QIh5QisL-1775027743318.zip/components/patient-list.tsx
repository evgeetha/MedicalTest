"use client"

import { Search, User, ChevronRight, AlertCircle } from "lucide-react"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { useState } from "react"
import { cn } from "@/lib/utils"

interface PatientListProps {
  selectedPatient: string | null
  onSelectPatient: (patientId: string) => void
}

const patients = [
  {
    id: "P001",
    name: "Sarah Johnson",
    age: 45,
    condition: "Diabetes, Hypertension",
    status: "warning",
    lastVisit: "Mar 20, 2026",
  },
  {
    id: "P002",
    name: "Michael Chen",
    age: 32,
    condition: "Asthma",
    status: "normal",
    lastVisit: "Mar 5, 2026",
  },
  {
    id: "P003",
    name: "Emily Davis",
    age: 67,
    condition: "Atrial Fibrillation",
    status: "warning",
    lastVisit: "Mar 15, 2026",
  },
  {
    id: "P004",
    name: "Robert Wilson",
    age: 55,
    condition: "GERD, Anxiety",
    status: "normal",
    lastVisit: "Feb 28, 2026",
  },
]

export function PatientList({ selectedPatient, onSelectPatient }: PatientListProps) {
  const [search, setSearch] = useState("")

  const filteredPatients = patients.filter(
    (patient) =>
      patient.name.toLowerCase().includes(search.toLowerCase()) ||
      patient.id.toLowerCase().includes(search.toLowerCase()) ||
      patient.condition.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="flex h-full flex-col bg-card rounded-xl border shadow-sm">
      <div className="border-b p-4">
        <h2 className="font-semibold text-card-foreground mb-3">Patients</h2>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search patients..."
            className="pl-9 bg-background"
          />
        </div>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-2">
          {filteredPatients.map((patient) => (
            <button
              key={patient.id}
              onClick={() => onSelectPatient(patient.id)}
              className={cn(
                "w-full flex items-center gap-3 rounded-lg p-3 text-left transition-colors hover:bg-muted",
                selectedPatient === patient.id && "bg-muted"
              )}
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
                <User className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-sm truncate">{patient.name}</p>
                  {patient.status === "warning" && (
                    <AlertCircle className="h-3.5 w-3.5 text-yellow-500 shrink-0" />
                  )}
                </div>
                <p className="text-xs text-muted-foreground truncate">
                  {patient.id} • {patient.age}y • {patient.condition}
                </p>
                <Badge variant="outline" className="mt-1 text-xs">
                  Last: {patient.lastVisit}
                </Badge>
              </div>
              <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
            </button>
          ))}
          {filteredPatients.length === 0 && (
            <p className="p-4 text-center text-sm text-muted-foreground">
              No patients found
            </p>
          )}
        </div>
      </ScrollArea>
    </div>
  )
}
